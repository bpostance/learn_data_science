from distutils.core import setup

setup(
    name='My_App',
    version='0.1dev',
    url='My_App_Website.com',
    author='Old Smaug',
    author_email='ask_me_later@email.com',
    packages=['my_app',],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README').read(),
)
